﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EmployeeCrud2.Models;

public partial class TestdbContext : DbContext
{
    public TestdbContext()
    {
    }

    public TestdbContext(DbContextOptions<TestdbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Appointment> Appointments { get; set; }

    public virtual DbSet<Country> Countries { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Docter> Docters { get; set; }

    public virtual DbSet<EmployeeList> EmployeeLists { get; set; }

    public virtual DbSet<Emptbl> Emptbls { get; set; }

    public virtual DbSet<Harish> Harishes { get; set; }

    public virtual DbSet<Joint> Joints { get; set; }

    public virtual DbSet<Login> Logins { get; set; }

    public virtual DbSet<Movie> Movies { get; set; }

    public virtual DbSet<Movie1> Movies1 { get; set; }

    public virtual DbSet<Patient> Patients { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UsersInfo> UsersInfos { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("server=200411LTP2749\\SQLEXPRESS; database=testdb; integrated security=true;Encrypt=false;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Appointment>(entity =>
        {
            entity.HasKey(e => e.Appointmentno);

            entity.ToTable("appointments");

            entity.Property(e => e.Appointmentno).HasColumnName("appointmentno");
            entity.Property(e => e.DocterId).HasColumnName("DocterID");
            entity.Property(e => e.PatientId).HasColumnName("patientID");
            entity.Property(e => e.Status).HasColumnName("status");
        });

        modelBuilder.Entity<Country>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__countrie__3213E83FE7C56867");

            entity.ToTable("countries");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Capital)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("capital");
            entity.Property(e => e.Currency)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("currency");
            entity.Property(e => e.Economy)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("economy");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Population).HasColumnName("population");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK__CUSTOMER__A4AE64D857C4770B");

            entity.ToTable("CUSTOMER");

            entity.HasIndex(e => e.CustomerNumber, "UQ__CUSTOMER__48D47E1E06882D34").IsUnique();

            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Phone)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Docter>(entity =>
        {
            entity.HasKey(e => e.Doctorno);

            entity.Property(e => e.Doctorno).HasColumnName("doctorno");
            entity.Property(e => e.Name).HasMaxLength(20);
            entity.Property(e => e.PhoneNumber).HasColumnType("numeric(18, 0)");
            entity.Property(e => e.VistingFee).HasColumnType("numeric(18, 2)");
        });

        modelBuilder.Entity<EmployeeList>(entity =>
        {
            entity.HasKey(e => e.EmployeId).HasName("PK__Employee__6251440F7D217347");

            entity.ToTable("EmployeeList");

            entity.Property(e => e.EmployeId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("EmployeID");
            entity.Property(e => e.EmployeName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Project)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Emptbl>(entity =>
        {
            entity.HasKey(e => e.Eno);

            entity.ToTable("emptbl");

            entity.Property(e => e.Eno)
                .ValueGeneratedNever()
                .HasColumnName("eno");
            entity.Property(e => e.City)
                .HasMaxLength(20)
                .HasColumnName("city");
            entity.Property(e => e.Name)
                .HasMaxLength(20)
                .HasColumnName("name");
            entity.Property(e => e.Salary)
                .HasColumnType("numeric(18, 0)")
                .HasColumnName("salary");
        });

        modelBuilder.Entity<Harish>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("harish");

            entity.Property(e => e.Currency)
                .HasMaxLength(60)
                .IsUnicode(false)
                .HasColumnName("currency");
            entity.Property(e => e.FirstName)
                .HasMaxLength(40)
                .IsUnicode(false)
                .HasColumnName("firstName");
            entity.Property(e => e.LastName)
                .HasMaxLength(40)
                .IsUnicode(false)
                .HasColumnName("lastName");
            entity.Property(e => e.Place)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("place");
        });

        modelBuilder.Entity<Joint>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Joint");

            entity.Property(e => e.FirstName)
                .HasMaxLength(40)
                .IsUnicode(false)
                .HasColumnName("firstName");
            entity.Property(e => e.LastName)
                .HasMaxLength(40)
                .IsUnicode(false)
                .HasColumnName("lastName");
            entity.Property(e => e.Place)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("place");
            entity.Property(e => e.Roll)
                .HasMaxLength(60)
                .IsUnicode(false)
                .HasColumnName("roll");
        });

        modelBuilder.Entity<Login>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("login");

            entity.Property(e => e.Password)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("password");
            entity.Property(e => e.Username)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("username");
        });

        modelBuilder.Entity<Movie>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Movie");

            entity.Property(e => e.Director)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Hero)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Language)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.MusicDirector)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ReleaseDate).HasColumnType("date");
            entity.Property(e => e.Review)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Title)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Movie1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Movies");

            entity.Property(e => e.Director)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Hero)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Language)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.MusicDirector)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ReleaseDate).HasColumnType("date");
            entity.Property(e => e.Review)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Title)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Patient>(entity =>
        {
            entity.Property(e => e.City).HasColumnName("city");
            entity.Property(e => e.Name).HasMaxLength(20);
            entity.Property(e => e.PhoneNumber).HasColumnType("numeric(18, 0)");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__users__CB9A1CDF2C97FBCC");

            entity.ToTable("users");

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("userID");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("firstName");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("lastName");
        });

        modelBuilder.Entity<UsersInfo>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__usersInf__CB9A1CDF481A6603");

            entity.ToTable("usersInfo");

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("userID");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("firstName");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("lastName");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
