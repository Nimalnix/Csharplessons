﻿using Microsoft.EntityFrameworkCore;
using System.Numerics;

namespace EmployeeCrud2.Models
{
    public class RepositoryEmployee
    {
        private TestdbContext _context;
        public RepositoryEmployee(TestdbContext context)
        {
            _context = context;
        }
        public List<EmployeeList> AllEmployees()
        {
            return _context.EmployeeLists.ToList();
        }
        public EmployeeList AddNewEmployee(EmployeeList newEmployee)
        {


            _context.EmployeeLists.Add(newEmployee);
            _context.SaveChanges();
            return newEmployee; // Return the newly added employee
        }
        public EmployeeList GetEmployeeListById(string id)
        {
            return _context.EmployeeLists.Find(id);
        }


        public void UpdateEmployeeById(EmployeeList employee)
        {
            TestdbContext ctx = new TestdbContext();
            ctx.Entry(employee).State = EntityState.Modified;
            ctx.SaveChanges();
        }



        public  void DeleteEmployee(string id)
        {
            EmployeeList newEmployee= _context.EmployeeLists.Find(id);
            _context.EmployeeLists.Remove(newEmployee);
            _context.SaveChanges();

        }
    }
}
