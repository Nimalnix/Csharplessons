﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Login
{
    public string? Username { get; set; }

    public string? Password { get; set; }


}
