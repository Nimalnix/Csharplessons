﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Harish
{
    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Place { get; set; }

    public string? Currency { get; set; }
}
