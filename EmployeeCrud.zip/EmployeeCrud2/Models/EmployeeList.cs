﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class EmployeeList
{
  
    public string EmployeId { get; set; } 

    public string? EmployeName { get; set; }

    public string? Project { get; set; }
}
