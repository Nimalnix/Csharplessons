﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Appointment
{
    public int Appointmentno { get; set; }

    public int PatientId { get; set; }

    public int DocterId { get; set; }

    public DateTime DateOfAppointment { get; set; }

    public bool Status { get; set; }
}
