﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Emptbl
{
    public int Eno { get; set; }

    public string Name { get; set; } = null!;

    public decimal Salary { get; set; }

    public string City { get; set; } = null!;
}
