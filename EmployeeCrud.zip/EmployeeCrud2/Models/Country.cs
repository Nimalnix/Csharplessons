﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Country
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Capital { get; set; }

    public int? Population { get; set; }

    public string? Economy { get; set; }

    public string? Currency { get; set; }
}
