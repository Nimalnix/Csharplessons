﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Joint
{
    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Place { get; set; }

    public string? Roll { get; set; }
}
