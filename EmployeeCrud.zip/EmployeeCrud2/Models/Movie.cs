﻿using System;
using System.Collections.Generic;

namespace EmployeeCrud2.Models;

public partial class Movie
{
    public int? Id { get; set; }

    public string? Title { get; set; }

    public string? Language { get; set; }

    public string? Hero { get; set; }

    public string? Director { get; set; }

    public string? MusicDirector { get; set; }

    public DateTime? ReleaseDate { get; set; }

    public int? Cost { get; set; }

    public int? Collection { get; set; }

    public string? Review { get; set; }
}
