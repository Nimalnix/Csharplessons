﻿using EmployeeCrud2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeCrud2.Controllers
{
    public class LoginController : Controller
    {
        private readonly TestdbContext _context;

        public LoginController(TestdbContext context)
        {
            _context = context;
        }
        public IActionResult Login(Login user)
        {
            var existingUser = _context.Logins.FirstOrDefault(u => u.Username == user.Username);

            if (existingUser != null)
            {
                if (existingUser.Password == user.Password)
                {
                    return RedirectToAction("Index","Employee");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid password.");
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "User not found.");
            }
            return View(user);
        }
    }
    }