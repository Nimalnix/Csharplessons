﻿using EmployeeCrud2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Numerics;

namespace EmployeeCrud2.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: EmployeeController
        private RepositoryEmployee _repositoryEmployee;
        public EmployeeController(RepositoryEmployee repository)
        {
            _repositoryEmployee = repository;
        }
        // GET: EmployeeController
        public ActionResult Index()
        {
            List<EmployeeList> employees = _repositoryEmployee.AllEmployees();
            return View(employees);
        }

        // GET: EmployeeController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection,EmployeeList employee)
        {
            try
            {
                _repositoryEmployee.AddNewEmployee(employee);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Edit/5

        public ActionResult Edit(string id)
        {
            EmployeeList employee = _repositoryEmployee.GetEmployeeListById(id);
            return View(employee);
        }

        // POST: DoctorController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string  id, IFormCollection collection, EmployeeList employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _repositoryEmployee.UpdateEmployeeById(employee);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(string id)
        {
            EmployeeList employee = _repositoryEmployee.GetEmployeeListById(id);
            return View(employee);
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(IFormCollection collection,string id)
        {
            try
            {
                _repositoryEmployee.DeleteEmployee(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
